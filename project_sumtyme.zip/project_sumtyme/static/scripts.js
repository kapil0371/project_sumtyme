const toggleButton = document.getElementById("toggle_checkbox");
const bodyElement = document.body;
const images = document.querySelectorAll("img");
let mode = true;
toggleButton.addEventListener("click", () => {
  bodyElement.classList.toggle("dark-theme");
  bodyElement.classList.toggle("light-theme");
});

toggleButton.addEventListener("click", () => {
  if (mode) {
    images.forEach((img) => {
      img.setAttribute("src", img.getAttribute("data-dark-src"));
    });
    let links = document.querySelectorAll(".first-links a");
    links[0].innerHTML = "Approach";
    links[1].innerHTML = "Models";
    document.querySelectorAll(".second-images").forEach((element) => {
      element.style.backgroundColor = "#e5e6e7";
    });
    document.querySelectorAll(".model-1").forEach((element) => {
      element.style.borderTop = "3px solid #333333";
    });
    document.querySelectorAll(".first-links a").forEach((element) => {
      element.style.color = "#333333";
    });
    document.querySelectorAll(".footer-right a").forEach((element) => {
      element.style.color = "#333333";
    });
    mode = false;
  } else {
    images.forEach((img) => {
      img.setAttribute("src", img.getAttribute("data-light-src"));
    });
    let links = document.querySelectorAll(".first-links a");
    links[0].innerHTML = " Our approach";
    links[1].innerHTML = " Our models";
    document.querySelectorAll(".second-images").forEach((element) => {
      element.style.backgroundColor = "#4d4d4d";
    });
    document.querySelectorAll(".model-1").forEach((element) => {
      element.style.borderTop = "3px solid white";
    });
    document.querySelectorAll(".first-links a").forEach((element) => {
      element.style.color = "white";
    });
    document.querySelectorAll(".footer-right a").forEach((element) => {
      element.style.color = "white";
    });
    mode = true;
  }
});
